#ifndef TEXTMODE_HPP
# define TEXTMODE_HPP
#   include "IMonitorDisplay.hpp"
#   include "DateTimeModule.hpp"
#   include "HostnameModule.hpp"
#   include "OSInfoModule.hpp"
#   include "CPUModule.hpp"
#   include "RAMModule.hpp"
#   include "NetworkModule.hpp"

class   TextMode : public IMonitorDisplay {
    public:
        TextMode();
        TextMode(TextMode const &);
        TextMode&   operator=(TextMode const &);
        ~TextMode();
        void begin( void );

    private:
        DateTimeModule       *_dateTime;
        HostnameModule    *_hostname;
        OSInfoModule      *_osinfo;
        CPUModule         *_cpuinfo;
        RAMModule         *_ram;
        NetworkModule		*_network;
};

#endif