
#ifndef GRAPHICMODE_HPP
#   define GRAPHICMODE_HPP
#   include "IMonitorDisplay.hpp"
#   include "DateTimeModule.hpp"
#   include "HostnameModule.hpp"
#   include "OSInfoModule.hpp"
#   include "CPUModule.hpp"
#   include "RAMModule.hpp"

class   GraphicMode : public IMonitorDisplay {
    public:
        GraphicMode();
        ~GraphicMode();
        GraphicMode(GraphicMode const & );
        GraphicMode& operator=(GraphicMode const &);

        void    begin();
    private:
        DateTimeModule        *_dateTime;
        HostnameModule    *_hostname;
        OSInfoModule      *_osinfo;
        CPUModule         *_cpuinfo;
        RAMModule         *_ram;
};

#endif