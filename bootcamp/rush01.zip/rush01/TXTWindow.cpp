#   include "TXTWindow.hpp"

TXTWindow::TXTWindow(std::string name): _name(name), HEIGHT(WINHEIGHT), WIDTH(WINWIDTH)
    , WSTARTX(WINSTARTX), WSTARTY(WINSTARTY) {
}

TXTWindow::~TXTWindow() {
    destructWin();
    endwin();
}

void	TXTWindow::createWin(int height, int width, int starty, int startx) {

    my_win = newwin(height, width, starty, startx);
    box(my_win, 0 , 0);
    wrefresh(my_win);
}

void	TXTWindow::destructWin() {
    wborder(my_win, ' ', ' ', ' ',' ',' ',' ',' ',' ');
    wrefresh(my_win);
    clear();
    refresh();
    delwin(my_win);
}


void	TXTWindow::initWin(int height, int width, int startx, int starty) {
    initscr();
    noecho();
    curs_set(false);
    cbreak();
    timeout(0);
    keypad(stdscr, true);

    refresh();
    createWin(height, width, starty, startx);
}
