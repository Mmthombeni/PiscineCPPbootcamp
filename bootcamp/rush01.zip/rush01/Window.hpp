#   ifndef  WINDOW_HPP
#   define  WINDOW_HPP
#   include <QWidget>
#   include <QGridLayout>
#   include <QTimer>
#   include <QObject>

#   include "DateTimeModule.hpp"
#   include "HostnameModule.hpp"
#   include "OSInfoModule.hpp"
#   include "CPUModule.hpp"
#   include "RAMModule.hpp"
#   include "NetworkModule.hpp"

QT_BEGIN_NAMESPACE
class QGroupBox;
QT_END_NAMESPACE

class   Window : public QWidget {
    public:
        Window(QWidget *parent = 0);
        Window(DateTimeModule *, HostnameModule * hostname, OSInfoModule * osinfo, CPUModule * cpuinfo, RAMModule * ram, NetworkModule *network, QWidget *parent = 0);

        private slots:
            void    qt_refresh();
    private:
        DateTimeModule        *_dateTime;
        HostnameModule    *_hostname;
        OSInfoModule      *_osinfo;
        CPUModule         *_cpuinfo;
        RAMModule         *_ram;
        NetworkModule     *_network;
        QTimer      *_timer;
        QGridLayout *_grid;
        QGroupBox   *createHourGroup();
        QGroupBox   *createHostNameGroup();
        QGroupBox   *createOSInfoGroup();
        QGroupBox   *createCPUGroup();
        QGroupBox   *createNewGroup();
        QGroupBox   *createPaquetGroup();
};

#endif