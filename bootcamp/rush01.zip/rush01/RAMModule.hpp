#ifndef RAMMODULE_HPP
#   define RAMMODULE_HPP
#   include <iostream>
#   include "TXTWindow.hpp"

class   RAMModule : public TXTWindow {
    public:
        RAMModule(void);
		~RAMModule(void);
        RAMModule(RAMModule const &);
		RAMModule		&operator=(RAMModule const &);
		const char* getUsedRAM( void );
		const char* getTotalRAM( void );
		void printWin( void );
		void begin( void );
};

#endif