/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HostnameModule.hpp                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: williamp <williamp@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/16 16:57:38 by wphokomp          #+#    #+#             */
/*   Updated: 2018/06/17 09:12:46 by williamp         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HOSTNAMEMODULE_HPP
#   define HOSTNAMEMODULE_HPP
#   include <string>
#   include <iostream>
#   include <unistd.h>
#   include "TXTWindow.hpp"

class   HostnameModule : public TXTWindow {
    public:
        HostnameModule();
        HostnameModule(HostnameModule const &);
        ~HostnameModule();
        HostnameModule		&operator=(HostnameModule const &);
        char* getHostname( void );
		char* getUsername( void );
		void    printWin( void );
		void    begin( void );
    private:
        char    *_cmd;
};

#endif