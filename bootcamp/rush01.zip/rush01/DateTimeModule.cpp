#   include "DateTimeModule.hpp"
#   include <string>

DateTimeModule::DateTimeModule() : TXTWindow("Date Time") {
    setDateTime();
}

DateTimeModule::~DateTimeModule() {}

void    DateTimeModule::setDateTime() {
    time_t rawtime;
    struct tm * timeinfo;

    time (&rawtime);
    timeinfo = localtime(&rawtime);

    strftime(_buff,80,"%d-%m-%Y %I:%M:%S",timeinfo);
}

const char  *DateTimeModule::getDateTime() {
    setDateTime();
    return (_buff);
}

void    DateTimeModule::printWin() {
    setDateTime();
    mvprintw(7, 6, getDateTime());
    refresh();
}

void    DateTimeModule::begin() {
    initWin(4, 101, 5, 5);
    printWin();
}