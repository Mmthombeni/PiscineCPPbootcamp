/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   OSInfoModule.hpp                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wphokomp <wphokomp@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/16 17:33:40 by wphokomp          #+#    #+#             */
/*   Updated: 2018/06/17 16:47:29 by wphokomp         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef OSINFOMODULE_HPP
#   define OSINFOMODULE_HPP
#   include "TXTWindow.hpp"
#	include <sys/types.h>
#	include <sys/sysctl.h>

class   OSInfoModule : public TXTWindow {
    public:
        OSInfoModule();
        OSInfoModule(char *);
        OSInfoModule(OSInfoModule const &);
        OSInfoModule    &operator=(OSInfoModule const &);
        ~OSInfoModule();

        char* 	getOSName( void );
		char* 	getOSProductVersion( void );
		char* 	getOSBuildVersion( void );
		char*		getOSType( void );

		void		setOSName( void );
		void		 	setOSProductVersion( void );
		void		 	setOSBuildVersion( void );
		void			setOSType( void );

		void printWin( void );
		void begin( void );

    private:
        char    _OSType[100];
        char	_OSBuildVersion[100];
		char	_OSProductVersion[100];
		char	_OSName[100];
};

#endif