/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   OSInfoModule.cpp                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wphokomp <wphokomp@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/16 17:40:10 by wphokomp          #+#    #+#             */
/*   Updated: 2018/06/17 16:41:53 by wphokomp         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#   include "OSInfoModule.hpp"

OSInfoModule::OSInfoModule( void ) : TXTWindow("OSInfoModule")
{
    setOSName();
    setOSProductVersion();
    setOSBuildVersion();
    setOSType();
}

OSInfoModule::~OSInfoModule( void )
{
}

char *        OSInfoModule::getOSName( void ) {
    return _OSName;
}

char *        OSInfoModule::getOSProductVersion( void ) {
    return _OSProductVersion;
}

char *        OSInfoModule::getOSBuildVersion( void ) {
    return _OSBuildVersion;    
}

char *        OSInfoModule::getOSType( void ) {
    return _OSType;    
}

void                OSInfoModule::setOSName( void ) {
    const char*     cmd ="sw_vers -productName";
    FILE*           pipe = popen(cmd, "r");

    if (!pipe)
        return ;

    while(!feof(pipe)) {
        fgets(_OSName, 128, pipe);
    }
    pclose(pipe);
}


void                OSInfoModule::setOSProductVersion( void ) {
    const char*     cmd ="sw_vers -productVersion";
    FILE*           pipe = popen(cmd, "r");
    
    if (!pipe)
        return ;
    
    while(!feof(pipe)) {
       fgets(_OSProductVersion, 128, pipe);
    }
    pclose(pipe);

}


void                OSInfoModule::setOSBuildVersion( void ) {
    const char*     cmd ="sw_vers -buildVersion";
    FILE*           pipe = popen(cmd, "r");

    if (!pipe)
        return ;
    
    while(!feof(pipe)) {
        fgets(_OSBuildVersion, 128, pipe);
    }
    pclose(pipe);
}

void                OSInfoModule::setOSType( void ) {
    size_t test2 = 100;

    sysctlbyname("kern.ostype", &_OSType, &test2, NULL, 0);
}


void                OSInfoModule::printWin( void ) {
    mvprintw(13, 47, "OS Name:");
    mvprintw(13, 70, getOSName());
    mvprintw(13, 105, "|");
    mvprintw(14, 47, "OS Product Version:");
    mvprintw(14, 70, getOSProductVersion());
    mvprintw(14, 105, "|");
    mvprintw(15, 47, "OS Build Version:");
    mvprintw(15, 70, getOSBuildVersion());
    mvprintw(15, 105, "|");
    mvprintw(16, 47, "OS Type:");
    mvprintw(16, 70, getOSType());
    refresh();
}

void                OSInfoModule::begin( void ) {
	printWin();
}
