#ifndef NETWORKMODULE_HPP
#   define NETWORKMODULE_HPP

#   include "TXTWindow.hpp"

class   NetworkModule : public TXTWindow {
    public:
        NetworkModule(void);
		~NetworkModule(void);
        NetworkModule(NetworkModule const &);
		NetworkModule		&operator=(NetworkModule const &);
		
		void			getNetworkValues();
		const char* 			getInputBytes( void ) const;
		const char* 			getOutputBytes( void ) const;
		const char* 			getInputPacket( void ) const;
		const char* 			getOutputPacket( void ) const;
		void 			printWin( void );
		void 			begin( void );

    private:
        const char*	_inBytes;
		const char*	_outBytes;
		const char*	_inPacket;
		const char*	_outPacket;
};

#endif