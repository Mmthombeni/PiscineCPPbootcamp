/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   DateTimeModule.hpp                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: williamp <williamp@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/16 17:50:52 by wphokomp          #+#    #+#             */
/*   Updated: 2018/06/17 09:11:08 by williamp         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DATETIMEMODULE_HPP
#   define DATETIMEMODULE_HPP
#   include <iostream>
#   include <sstream>
#   include "TXTWindow.hpp"

class   DateTimeModule : public TXTWindow {
    public:
        DateTimeModule();
        DateTimeModule(DateTimeModule const &);
        DateTimeModule  &operator=(DateTimeModule const &);
        ~DateTimeModule();
        const char*		getDateTime( void );
		void			setDateTime( void );
		void			printWin( void );
		void			begin( void );

    private:
        char    _buff[100];
        
};

#endif