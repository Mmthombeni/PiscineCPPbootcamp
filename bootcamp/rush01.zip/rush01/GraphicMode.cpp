#   include "GraphicMode.hpp"

GraphicMode::GraphicMode() : _dateTime(new DateTimeModule()), _hostname(new HostnameModule()),
    _osinfo(new OSInfoModule()), _cpuinfo(new CPUModule()), _ram(new RAMModule()) {}

GraphicMode::~GraphicMode() {}

void    GraphicMode::begin() {}