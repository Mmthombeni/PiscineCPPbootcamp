#   include "TextMode.hpp"
#   include <unistd.h>

TextMode::TextMode() : _dateTime(new DateTimeModule()), _hostname(new HostnameModule()), _osinfo(new OSInfoModule())
    , _cpuinfo(new CPUModule()), _ram(new RAMModule()), _network(new NetworkModule()) {}

TextMode::~TextMode( void ) {

}

void TextMode::begin ( void ) {
    _dateTime->begin();
    _hostname->begin();
    _osinfo->begin();
    _cpuinfo->begin();
    _ram->begin();
    _network->begin();
    int input = 0;

   	input = getch();
    while (input != 27)
    {
    	input = getch();
        _dateTime->printWin();
        _hostname->printWin();
        _osinfo->printWin();
        _cpuinfo->printWin();
        _ram->printWin();
        _network->printWin();
        usleep(1000000);
    }
    delete _hostname;
    delete _osinfo;
    delete _dateTime;
    delete _cpuinfo;
    delete _ram;
    delete _network;
}