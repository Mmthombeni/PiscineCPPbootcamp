#ifndef CPUMODULE_HPP
 #define CPUMODULE_HPP
#   include <iostream>
#   include "TXTWindow.hpp"

class   CPUModule : public TXTWindow {
    public:
		CPUModule(void);
        CPUModule(CPUModule const &);
		~CPUModule(void);

		CPUModule		&operator=(CPUModule const &);
		char* getTotalVM( void );
		char* getMachine( void );
		const char* getPhysicalMem( void );
		std::string getCPUName( void );
		char* getClockRate( void );	
		char* getCPUUsage( void );
		char* getCPUUsage2( void );		

		void setClockRate( void );
		void setCPUUsage( double cpu_usage );
		void printWin( void );
		void initUsage( void );
		void begin( void );
    private:
        double CPUUsage;
		double oldWork;
		double newWork;
		double oldTotal;
		double newTotal;
		char		_CPUUsage[50];
		char		_ClockRate[50];
};

#endif