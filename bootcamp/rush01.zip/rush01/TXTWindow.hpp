#ifndef TXTWINDOW_HPP
# define TXTWINDOW_HPP

#define WINHEIGHT 5
#define WINWIDTH 40
#define WINSTARTX 5
#define WINSTARTY 5

#include <ncurses.h>
#include <sys/time.h>
#include <iostream>
#include <cstdlib>
#include "IMonitorModule.hpp"

class   TXTWindow : public IMonitorModule {
    protected:
        const std::string _name;
        const int	HEIGHT;
        const int	WIDTH;
        const int	WSTARTX;
        const int	WSTARTY;
        WINDOW		*my_win;

        void	initWin(int height, int width, int startx, int starty);
        void	destructWin();
        void	createWin(int height, int width, int startx, int starty);
    public:
        TXTWindow(TXTWindow const &);
        TXTWindow const &	operator=(TXTWindow const &);
        TXTWindow();
        TXTWindow(std::string name);
        virtual ~TXTWindow();
        virtual void    begin() = 0;
        virtual void    printWin() = 0;
};

#endif
