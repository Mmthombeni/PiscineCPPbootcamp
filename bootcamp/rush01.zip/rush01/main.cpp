// #   include <QApplication>

#   include "TXTWindow.hpp"
#   include "DateTimeModule.hpp"
#   include "HostnameModule.hpp"
#   include "OSInfoModule.hpp"
#   include "CPUModule.hpp"
#   include "NetworkModule.hpp"
#   include "RAMModule.hpp"
#   include "TextMode.hpp"
#   include "GraphicMode.hpp"
#   include <unistd.h>


int     main( void ) {
    std::cout << "Choose your display" << std::endl << "1: Graphic" << std::endl << "2: Terminal" << std::endl;
    std::string input;
    std::cin >> input;

    if (input == "1") {
        // QApplication application(argc, argv);
        // DateTimeModule        *dateTime = new DateTimeModule();
        // HostnameModule    *hostname = new HostnameModule();
        // OSInfoModule      *osinfo = new OSInfoModule();
        // CPUModule         *cpuinfo = new CPUModule();
        // RAMModule         *ram = new RAMModule();
        // NetworkModule     *network = new NetworkModule();
        // Window      win(dateTime, hostname, osinfo, cpuinfo, ram, network);
        
        // win.show();
        // application.exec();
    } else if (input == "2") {
        TextMode    _disp;
        _disp.begin();
    } else {
        std::cout << "ERROR: Please choose 1 or 2." << std::endl;
    }

    return (0);
}