#include "HostnameModule.hpp"

HostnameModule::HostnameModule( void ) : TXTWindow("Hostname") {
}

HostnameModule::~HostnameModule( void ) {
}

char    *HostnameModule::getHostname() {
    char hostname[1024];
	hostname[1023] = '\0';
	gethostname(hostname, 1023);
	char	*_hs = hostname;
	return _hs;
}

char* HostnameModule::getUsername( void ) {

	char username[1024];
	username[1023] = '\0';
	getlogin_r(username, 1023);
	char	*_un = username;
	return _un;
}

void	HostnameModule::printWin( void ) {
	mvprintw(10, 71, "COMPUTER");
	mvprintw(12, 47, "Hostname:");
    mvprintw(12, 70, getHostname());
    mvprintw(6, 6, getUsername());
    refresh();
}

void HostnameModule::begin( void ) {
	initWin(9, 60, 46, 9);
	printWin();
}