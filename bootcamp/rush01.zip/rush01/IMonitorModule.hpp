/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   IMonitorModule.hpp                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wphokomp <wphokomp@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/17 16:42:35 by wphokomp          #+#    #+#             */
/*   Updated: 2018/06/17 16:42:36 by wphokomp         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef IMONITORMODULE_HPP
#   define IMONITORMODULE_HPP

#   include <iostream>
class   IMonitorModule {
    public:
        virtual void    begin() = 0;
        virtual void    printWin() = 0;
};

#endif